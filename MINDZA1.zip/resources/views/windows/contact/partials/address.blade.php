<div class="contact-address mt-30">
    <ul>
        <li>
            <div class="single-address">
                <div class="icon">
                    <i class="fa fa-home"></i>
                </div>
                <div class="cont">
                    <p>Koppam, Thiruvegappura (PO) 678001 (PIN), Palakkad, Kerala, India</p>
                </div>
            </div>
            <!-- single address -->
        </li>
        <li>
            <div class="single-address">
                <div class="icon">
                    <i class="fa fa-phone"></i>
                </div>
                <div class="cont">
                    <p>+91 99463 33396</p>
                    {{-- <p>+1 222 345 342</p> --}}
                </div>
            </div>
            <!-- single address -->
        </li>
        <li>
            <div class="single-address">
                <div class="icon">
                    <i class="fa fa-envelope-o"></i>
                </div>
                <div class="cont">
                    <p>mindzaschoolofhappiness@gmail.com</p>
                    {{-- <p>help.pixelcurve@gmail.com</p> --}}
                </div>
            </div>
            <!-- single address -->
        </li>
    </ul>
</div>
<!-- contact address -->
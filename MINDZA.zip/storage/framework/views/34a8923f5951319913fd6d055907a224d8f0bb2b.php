<!--====== TEACHERS PART START ======-->

<section id="teachers-part" class="pt-70 pb-120">
    <div class="container">
        <div class="row">
            
            <div class="section-title mt-50">
                <h5>Featured Faculties</h5>
                <h2>Meet our faculties</h2>
            </div> <!-- section title -->
            
            <div class="teachers mt-20">
                <div class="row">
                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 col-lg-3">
                            <div class="single-teachers mt-30 text-center">
                                <div class="image">
                                    <img src="<?php echo e(asset('images/teacher') . '/' . $teacher->image); ?>" alt="Teachers">
                                </div>
                                <div class="cont">
                                    <a href="/teachers/<?php echo e($teacher->id); ?>">
                                        <h6><?php echo e($teacher->name); ?></h6>
                                    </a>
                                    <span><?php echo e($teacher->position); ?></span>
                                </div>
                            </div> <!-- single teachers -->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    
                </div> <!-- row -->
            </div>
            
            
            
            
        </div> <!-- row -->
    </div> <!-- container -->
</section>

<!--====== TEACHERS PART ENDS ======-->
<?php /**PATH C:\Users\PC-07\Documents\MINDZA\resources\views/windows/home/partials/teachers.blade.php ENDPATH**/ ?>
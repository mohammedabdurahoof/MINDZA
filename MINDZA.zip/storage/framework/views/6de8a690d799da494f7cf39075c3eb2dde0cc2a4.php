<!--====== HEADER PART START ======-->

<header id="header-part">
    <div class="header-top d-none d-lg-block">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="header-contact">
                        <ul>
                            <li><i class="fa fa-envelope"></i><a
                                    href="mailto:mindzaschoolofhappiness@gmail.com">mindzaschoolofhappiness@gmail.com</a></li>
                            <li><i class="fa fa-phone"></i><a href="tel:+91 99463 33396">+91 99463 33396</a></li>
                        </ul>
                    </div> <!-- header contact -->
                </div>
                <div class="col-md-6">
                    <div class="header-right d-flex justify-content-end">
                        <div class="social d-flex">
                            <span class="follow-us">Follow Us :</span>
                            <ul>
                                <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                
                            </ul>
                        </div> <!-- social -->
                        <div class="login-register">
                            <ul>
                                <?php if(auth()->user()): ?>
                                    <li><a href="/dashboard"><?php echo e(Auth::User()->name); ?></a></li>
                                <?php else: ?>
                                    <li><a href="/login">Login</a></li>
                                    <li><a href="/register">Register</a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div> <!-- header right -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </div> <!-- header top -->

    <div class="navigation">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <nav class="navbar navbar-expand-lg">
                        <a class="navbar-brand" href="/">
                            <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="Logo">
                        </a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse"
                            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>

                        <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item">
                                    <a class="<?php echo e(request()->is('/') ? 'active' : ''); ?>" href="/">Home</a>
                                    
                                </li>

                                <li class="nav-item">
                                    <a class="<?php echo e(request()->is('courses') ? 'active' : ''); ?>"
                                        href="/courses">Courses</a>
                                    
                                </li>
                                <li class="nav-item">
                                    <a class="<?php echo e(request()->is('events') ? 'active' : ''); ?>" href="/events">Events</a>
                                    
                                </li>
                                <li class="nav-item">
                                    <a class="<?php echo e(request()->is('teachers*') ? 'active' : ''); ?>"
                                        href="/teachers">Teachers</a>
                                    
                                </li>

                                <li class="nav-item">
                                    <a class="<?php echo e(request()->is('shop*') ? 'active' : ''); ?>" href="/shop">Shop</a>
                                    
                                </li>

                                <li class="nav-item">
                                    <a class="<?php echo e(request()->is('gallery', 'policy', 'faq') ? 'active' : ''); ?>"
                                        href="#">Pages</a>
                                    <ul class="sub-menu">
                                        <li><a class="<?php echo e(request()->is('gallery') ? 'active' : ''); ?>"
                                                href="/gallery">Gallery</a></li>
                                        <li><a class="<?php echo e(request()->is('policy') ? 'active' : ''); ?>"
                                                href="/policy">Privacy Policy</a></li>
                                        <li><a class="<?php echo e(request()->is('faq') ? 'active' : ''); ?>"
                                                href="/faq">FAQ</a></li>
                                    </ul>
                                </li>
                                <li class="nav-item">
                                    <a class="<?php echo e(request()->is('about') ? 'active' : ''); ?>" href="/about">About
                                        Us</a>
                                </li>
                                
                                <li class="nav-item">
                                    <a class="<?php echo e(request()->is('contact') ? 'active' : ''); ?>"
                                        href="/contact">Contact</a>
                                    
                                </li>
                            </ul>
                        </div>
                        
                    </nav> <!-- nav -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </div>
</header>

<!--====== HEADER PART ENDS ======-->
<?php /**PATH C:\Users\PC-07\Documents\MINDZA\resources\views/partials/header.blade.php ENDPATH**/ ?>
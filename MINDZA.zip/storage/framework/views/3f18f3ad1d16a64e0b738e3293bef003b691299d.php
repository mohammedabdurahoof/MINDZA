<section id="course-part" class="pt-115 pb-120 gray-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="section-title pb-45">
                    <h5>Our course</h5>
                    <h2>Featured courses </h2>
                </div> <!-- section title -->
            </div>
        </div> <!-- row -->
        <div class="row course-slide mt-30">
            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="single-course mt-30">
                        <div class="thum">
                            <div class="image">
                                <img src="<?php echo e(asset('images/course') . '/' . $courses->courseImage); ?>" alt="Course">
                            </div>
                            <div class="price">
                                <span>₹<?php echo e($courses->price); ?></span>
                            </div>
                        </div>
                        <div class="cont">
                            <ul>
                                <li><i class="fa fa-star"></i></li>
                                <li><i class="fa fa-star"></i></li>
                                <li><i class="fa fa-star"></i></li>
                                <li><i class="fa fa-star"></i></li>
                                <li><i class="fa fa-star"></i></li>
                            </ul>
                            <span>(20 Reviews)</span><br>
                            <a href="/courses/<?php echo e($courses->id); ?>">
                                <h4><?php echo e($courses->courseName); ?></h4>
                            </a>
                            <div class="course-teacher">
                                <div class="thum">
                                    <a href="/teachers/<?php echo e($courses->teacherId); ?>"><img
                                            src="<?php echo e(asset('images/teacher') . '/' . $courses->teacherImage); ?>"
                                            alt="teacher"></a>
                                </div>
                                <div class="name">
                                    <a href="/teachers/<?php echo e($courses->teacherId); ?>">
                                        <h6><?php echo e($courses->name); ?></h6>
                                    </a>
                                </div>
                                <div class="admin">
                                    <ul>
                                        <li><a href="#"><i class="fa fa-user"></i><span>31</span></a>
                                        </li>
                                        <li><a href="#"><i class="fa fa-heart"></i><span>10</span></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- single course -->
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div> <!-- course slide -->
    </div> <!-- container -->
</section>
<?php /**PATH C:\Users\PC-07\Documents\MINDZA\resources\views/windows/home/partials/course.blade.php ENDPATH**/ ?>
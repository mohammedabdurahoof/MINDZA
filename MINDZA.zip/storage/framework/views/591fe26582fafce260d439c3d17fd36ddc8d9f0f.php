<div id="counter-part" class="bg_cover pt-65 pb-110 mt-5" data-overlay="8" style="background-image: url(<?php echo e(asset('assets/images/bg-2.jpg')); ?>)">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-sm-6">
                <div class="single-counter text-center mt-40">
                    <span><span class="counter">30,000</span>+</span>
                    <p>Students enrolled</p>
                </div> <!-- single counter -->
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="single-counter text-center mt-40">
                    <span><span class="counter">41,000</span>+</span>
                    <p>Courses Uploaded</p>
                </div> <!-- single counter -->
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="single-counter text-center mt-40">
                    <span><span class="counter">11,000</span>+</span>
                    <p>People certificate</p>
                </div> <!-- single counter -->
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="single-counter text-center mt-40">
                    <span><span class="counter">39,000</span>+</span>
                    <p>Global Teachers</p>
                </div> <!-- single counter -->
            </div>
        </div> <!-- row -->
    </div> <!-- container -->
</div><?php /**PATH C:\Users\PC-07\Documents\MINDZA\resources\views/windows/home/partials/counter.blade.php ENDPATH**/ ?>
<section id="category-2-part">
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <div class="section-title mt-50">
                    <h5>About us</h5>
                    <h2>Welcome to Mindza </h2>
                </div> <!-- section title -->
                <div class="about-cont">
                    <p>Mindza is dedicated to promoting mental well-being and empowering individuals to overcome
                        challenges, enhance their resilience, and lead more fulfilling lives. By blending convenience,
                        expertise, and compassion, Mindza continues to make a positive impact in the realm of online
                        mental health services.<br> </p>
                    <a href="/about" class="main-btn mt-55">Learn More</a>
                </div>
            </div> <!-- about cont -->
            
            <div class="col-lg-5 offset-lg-1">
                <div class="category-form">
                    <div class="form-title text-center">
                        <h3>Get 50 courses free!</h3>
                        <span>Sign up now </span>
                    </div>
                    <div class="main-form">
                        <form action="<?php echo e(route('student.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="single-form">
                                <input type="text" placeholder="Your name" required name="name"
                                    value="<?php echo e(old('name')); ?>">
                            </div>
                            <div class="single-form">
                                <input type="email" placeholder="Your Email" required name="email"
                                    value="<?php echo e(old('email')); ?>">
                            </div>
                            <div class="single-form">
                                <input type="tel" placeholder="Your Mobile Number" required name="phone"
                                    value="<?php echo e(old('phone')); ?>">
                            </div>
                            <div class="single-form">
                                <select class="form-control" name="course" id="exampleFormControlSelect1" required>
                                    <option selected value="">choose a course</option>
                                    <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($course->id); ?>"><?php echo e($course->courseName); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="single-form">
                                <button class="main-btn" type="submit">Register Now</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div> <!-- row -->
    </div> <!-- container -->
</section>
<?php /**PATH C:\Users\PC-07\Documents\MINDZA\resources\views/windows/home/partials/apply.blade.php ENDPATH**/ ?>
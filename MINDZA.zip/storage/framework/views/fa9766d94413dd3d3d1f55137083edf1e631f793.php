<section id="event-part" class="pt-50 pb-100">
    <div class="container">
        <div class="event-bg bg_cover" style="background-image: url(<?php echo e(asset('assets/images/bg-3.jpg')); ?>)">
            <div class="row">
                <div class="col-lg-5 offset-lg-6 col-md-8 offset-md-2 col-sm-10 offset-sm-1">
                    <div class="event-2 pt-90 pb-70">
                        <div class="event-title">
                            <h3>Upcoming events</h3>
                        </div> <!-- event title -->
                        <ul>
                            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <div class="single-event">
                                        
                                        <a href="/events/<?php echo e($event->id); ?>">
                                            <h4><?php echo e($event->name); ?></h4>
                                        </a>
                                        <span><i class="fa fa-clock-o"></i><?php echo e($event->startTime); ?> -
                                            <?php echo e($event->finishTime); ?></span>
                                        <span><i class="fa fa-map-marker"></i><?php echo e($event->address); ?></span>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </ul>
                        <a class="show-more" href="/events">Show more</a> 
                    </div> <!-- event 2 -->
                </div>
            </div> <!-- row -->
        </div>
    </div> <!-- container -->
</section>
<?php /**PATH C:\Users\PC-07\Documents\MINDZA\resources\views/windows/home/partials/upcoming.blade.php ENDPATH**/ ?>


<?php $__env->startSection('contant'); ?>
   
    <!--====== SEARCH BOX PART START ======-->
    
    <div class="search-box">
        <div class="search-form">
            <div class="closebtn">
                <span></span>
                <span></span>
            </div>
            <form action="#">
                <input type="text" placeholder="Search by keyword">
                <button><i class="fa fa-search"></i></button>
            </form>
        </div> <!-- search form -->
    </div>
    
    <!--====== SEARCH BOX PART ENDS ======-->
   
   
    <?php echo $__env->make('windows.home.partials.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--====== CATEGORY PART START ======-->
    <?php echo $__env->make('windows.home.partials.apply', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    
    <!--====== CATEGORY PART ENDS ======-->
    <?php echo $__env->make('windows.home.partials.counter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
   
    <!--====== APPLY PART START ======-->
    
    
    
    <!--====== APPLY PART ENDS ======-->
   
    <!--====== COURSE PART START ======-->
    
    <?php echo $__env->make('windows.home.partials.course', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!--====== COURSE PART ENDS ======-->
   
    <!--====== VIDEO FEATURE PART START ======-->
    
    <?php echo $__env->make('windows.home.partials.feature', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!--====== VIDEO FEATURE PART ENDS ======-->
   
    
    <?php echo $__env->make('windows.home.partials.teachers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('windows.home.partials.shop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('windows.home.partials.upcoming', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
   
    <!--====== TEASTIMONIAL PART START ======-->
    
    
    
    <!--====== TEASTIMONIAL PART ENDS ======-->
   
   
   
    <!--====== PATNAR LOGO PART START ======-->
    
    
    <!--====== PATNAR LOGO PART ENDS ======-->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC-07\Documents\MINDZA\resources\views/windows/home/index.blade.php ENDPATH**/ ?>
 <!--====== NEWS PART START ======-->
    
 <section id="news-part" class="pt-115 pb-110">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="section-title pb-50">
                    <h5>Latest News</h5>
                    <h2>From the news</h2>
                </div> <!-- section title -->
            </div>
        </div> <!-- row -->
        <div class="row">
            <div class="col-lg-6">
                <div class="single-news mt-30">
                    <div class="news-thum pb-25">
                        <img src="images/news/n-1.jpg" alt="News">
                    </div>
                    <div class="news-cont">
                        <ul>
                            <li><a href="#"><i class="fa fa-calendar"></i>2 December 2018 </a></li>
                            <li><a href="#"> <span>By</span> Adam linn</a></li>
                        </ul>
                        <a href="blog-single.html"><h3>Tips to grade high cgpa in university life</h3></a>
                        <p>Lorem ipsum gravida nibh vel velit auctor aliquetn sollicitudirem quibibendum auci elit cons equat ipsutis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt .</p>
                    </div>
                </div> <!-- single news -->
            </div>
            <div class="col-lg-6">
                <div class="single-news news-list">
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="news-thum mt-30">
                                <img src="images/news/ns-1.jpg" alt="News">
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <div class="news-cont mt-30">
                                <ul>
                                    <li><a href="#"><i class="fa fa-calendar"></i>2 December 2018 </a></li>
                                    <li><a href="#"> <span>By</span> Adam linn</a></li>
                                </ul>
                                <a href="blog-single.html"><h3>Intellectual communication</h3></a>
                                <p>Gravida nibh vel velit auctor aliquetn sollicitudirem quibibendum auci elit cons  vel.</p>
                            </div>
                        </div>
                    </div> <!-- row -->
                </div> <!-- single news -->
                <div class="single-news news-list">
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="news-thum mt-30">
                                <img src="images/news/ns-2.jpg" alt="News">
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <div class="news-cont mt-30">
                                <ul>
                                    <li><a href="#"><i class="fa fa-calendar"></i>2 December 2018 </a></li>
                                    <li><a href="#"> <span>By</span> Adam linn</a></li>
                                </ul>
                                <a href="blog-single.html"><h3>Study makes you perfect</h3></a>
                                <p>Gravida nibh vel velit auctor aliquetn sollicitudirem quibibendum auci elit cons  vel.</p>
                            </div>
                        </div>
                    </div> <!-- row -->
                </div> <!-- single news -->
                <div class="single-news news-list">
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="news-thum mt-30">
                                <img src="images/news/ns-3.jpg" alt="News">
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <div class="news-cont mt-30">
                                <ul>
                                    <li><a href="#"><i class="fa fa-calendar"></i>2 December 2018 </a></li>
                                    <li><a href="#"> <span>By</span> Adam Linn</a></li>
                                </ul>
                                <a href="blog-single.html"><h3>Technology eduction is now....</h3></a>
                                <p>Gravida nibh vel velit auctor aliquetn sollicitudirem quibibendum auci elit cons  vel.</p>
                            </div>
                        </div>
                    </div> <!-- row -->
                </div> <!-- single news -->
            </div>
        </div> <!-- row -->
    </div> <!-- container -->
</section>

<!--====== NEWS PART ENDS ======-->